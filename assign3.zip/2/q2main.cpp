#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>    // sqrt
#include <cstdlib>  // atoi, rand
#include <uActor.h>
#include "q2quicksort.h"  

using namespace std;

static void printUsage(const char *prog) {
    cerr << "Usage:\n"
         << "  sort: " << prog << " [unsorted-file | 'd' [sorted-file | 'd' [depth >=0]]] \n"
         << "  time: " << prog << " -t size (>=0) [depth >=0]\n";
    exit(1);
}

// sort
void sortMode(const char *inputFile, const char *outputFile, unsigned int depth) {
    istream *in = &cin;
    ifstream fin;
    if (strcmp(inputFile, "d") != 0) {
        fin.open(inputFile);
        if (!fin) {
            cerr << "err: " << inputFile << endl;
            exit(1);
        }
        in = &fin;
    }

    ostream *out = &cout;
    ofstream fout;
    if (outputFile && strcmp(outputFile, "d") != 0) {
        fout.open(outputFile);
        if (!fout) {
            cerr << "err: " << outputFile << endl;
            exit(1);
        }
        out = &fout;
    }

    while(true) {
        int n;
        if(!(*in >> n)) break; 
        if(n < 0) {
            cerr << "err: " << n << endl;
            break;
        }
        vector<int> data(n);
        for(int i = 0; i < n; i++) {
            if(!(*in >> data[i])) {
                cerr << "err\n";
                return;
            }
        }

        
        //cout<<"yuanshi"<<endl;
        for(int i = 0; i < n; i++) {
            *out << data[i] << " ";
        }
        *out << "\n";

        // depth
        if(depth > 0) {
            uProcessor p[(1 << depth) - 1] __attribute__((unused));
        }

        // quicksort
        quicksort(data.data(), 0, data.size(), depth);

        //cout<<(type)data<<endl;

        
        //cout<<"paixuhou"<<endl;
        for(int i = 0; i < n; i++) {
            *out << data[i] << " ";
        }
        *out << "\n\n"; 
    }
}

// time
void timeMode(unsigned int size, unsigned int depth) {
    if(depth > 0) {
        uProcessor p[(1 << depth) - 1] __attribute__((unused));
    }

    // 
    vector<int> data(size);
    for(unsigned int i = 0; i < size; i++) {
        data[i] = size - i;  
    }

    
    unsigned int times = (unsigned int) sqrt((double)size);
    for(unsigned int i = 0; i < times; i++) {
        unsigned int idx = rand() % size;
        std::swap(data[0], data[idx]);
    }

    // uClock
    uTime start = uClock::currTime();
    quicksort(data.data(), 0, data.size(), depth);
    uTime end = uClock::currTime();

    // 
    cout << "Sort time " << (end - start) << " sec." << endl;
}

int main(int argc, char *argv[]) {
    
    if(argc < 2) {
        printUsage(argv[0]);
    }
    if(strcmp(argv[1], "-t") == 0) {
        // time
        if(argc < 3) {
            cerr << "err \n";
            printUsage(argv[0]);
        }
        unsigned int size = atoi(argv[2]);
        unsigned int depth = 0;
        if(argc >= 4) {
            depth = atoi(argv[3]);
        }
        timeMode(size, depth);
    } else {
        // sort
        const char *infile = argv[1];
        const char *outfile = (argc >= 3 ? argv[2] : "d");
        unsigned int depth = 0;
        if(argc >= 4) {
            depth = atoi(argv[3]);
        }
        sortMode(infile, outfile, depth);
    }
    
    return 0;
}
