#ifndef Q2_QUICKSORT_H
#define Q2_QUICKSORT_H

#include <algorithm>     // for std::swap
#include <uC++.h>        // 
#include <iostream>
#include <uActor.h>
#include <uCobegin.h>

using namespace  std;
//-----------------------------------------
// Partition
//-----------------------------------------
template<typename T>
unsigned int partition( T values[], unsigned int low, unsigned int high ) {
    
    if ( high - low <= 1 ) return low;
    unsigned int pivotIndex = low + ( high - low ) / 2;
    T pivot = values[pivotIndex];

    unsigned int i = low;
    unsigned int j = high - 1;

    while (true) {
        while (i < high && values[i] < pivot) i++;
        while (j > low  && values[j] > pivot) j--;
        if (i >= j) break;
        std::swap(values[i], values[j]);
        i++;
        if (j > 0) j--;
    }
    return i;  
}


template<typename T>
void seqQuicksort( T values[], unsigned int low, unsigned int high ) {
    if ( high - low <= 1 ) return;
    unsigned int mid = partition(values, low, high);
    seqQuicksort(values, low, mid);
    seqQuicksort(values, mid, high);
}

//-----------------------------------------
//CBEGIN/COEND
//-----------------------------------------
#if defined(CBEGIN)
template<typename T>
void cbeginQuicksort( T values[], unsigned int low, unsigned int high, unsigned int depth ) {
    if ( high - low <= 1 ) return;
    unsigned int mid = partition(values, low, high);
    if ( depth > 0 ) {
        //  COBEGIN/COEND 
        COBEGIN
            BEGIN cbeginQuicksort(values, low, mid, depth - 1); END // 
            BEGIN cbeginQuicksort(values, mid, high, depth - 1); END
        COEND;
    } else {
        // 
        seqQuicksort(values, low, mid);
        seqQuicksort(values, mid, high);
    }
}
#endif // CBEGIN

//-----------------------------------------
// _Task 
//-----------------------------------------
#if defined(TASK)
template<typename T>
_Task QuickSortTask {
    T* values;
    unsigned int low, high, depth;
    void main() {
        if ( high - low <= 1 ) return; 
        unsigned int mid = partition(values, low, high);
        if ( depth > 0 ) {
            // left
            QuickSortTask<T> left( values, low, mid, depth - 1 );
            // right
            seqQuicksort(values, mid, high);
        } else {
            // 
            seqQuicksort(values, low, mid);
            seqQuicksort(values, mid, high);
        }
    }
  public:
    QuickSortTask( T* vals, unsigned int l, unsigned int h, unsigned int d )
        : values(vals), low(l), high(h), depth(d) {}
};
#endif // TASK

//-----------------------------------------
// _Actor
// 
//-----------------------------------------
#if defined(ACTOR)

template<typename T>
struct SortMessage : public uActor::Message {
    T* values;
    unsigned int low, high, depth;
    SortMessage(T* v, unsigned int l, unsigned int h, unsigned int d)
        :values(v),  low(l), high(h), depth(d) {
            
            
        }
};

//  Actor 
template<typename T>
_Actor QuickSortActor {
    
    uActor::Allocation receive(uActor::Message &msg) {
        Case(SortMessage<T>, msg) {
            osacquire acq( cout );
            
            if (msg_d->low >= msg_d->high) {
                delete msg_d; 
                return uActor::Delete;
            }
            /*cout<<"low:"<<msg_d->low<<" high:"<<msg_d->high<<endl;
            
            cout<< "before sorting "<<endl;
            for(int i=msg_d->low;i<msg_d->high;i++)
                cout<<msg_d->values[i]<<" ";
            cout << endl;*/
            unsigned int mid = partition(msg_d->values, msg_d->low, msg_d->high);
            /*cout << " mid " << mid<<endl;
            cout << "after sorting "<<endl;
            for(int i=msg_d->low;i<msg_d->high;i++)
                cout<<msg_d->values[i]<<" ";
            cout << endl;*/
            if (msg_d->depth > 0) {
                
                QuickSortActor<T>* left = new QuickSortActor<T>();
                *left | *new SortMessage<T>(msg_d->values, msg_d->low, mid, msg_d->depth - 1);
                QuickSortActor<T>* right = new QuickSortActor<T>();
                *right | *new SortMessage<T>(msg_d->values, mid, msg_d->high, msg_d->depth - 1);
            } else {
                
                seqQuicksort(msg_d->values, msg_d->low, mid);
                seqQuicksort(msg_d->values, mid, msg_d->high);
            }
            delete msg_d; 
            return uActor::Delete;
        }
        else Case(uActor::StopMsg, msg) {
            return uActor::Delete;
        }
        return uActor::Delete;
    }
};
#endif // ACTOR

//-----------------------------------------
//quicksort 
//-----------------------------------------
template<typename T>
void quicksort( T values[], unsigned int low, unsigned int high, unsigned int depth ) {
#if defined(CBEGIN)
    cbeginQuicksort(values, low, high, depth);
#elif defined(ACTOR)
    {
        uActor::start();
        //  Actor
        *new QuickSortActor<T>() | *new SortMessage<T>(values, low, high, depth);
        uActor::stop();
    }
#elif defined(TASK)
    {
        QuickSortTask<T> top(values, low, high, depth);
    }
#else
    seqQuicksort(values, low, high);
#endif
}

#endif // Q2_QUICKSORT_H
