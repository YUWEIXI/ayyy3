#include <iostream>
#include <cstdlib>
#include <cassert>

#include "BargingCheck.h"

// --------------------------------------------------------------------
// PoisonException
// --------------------------------------------------------------------
_Exception PoisonException {
public:
    // Exception type for poisoning
    PoisonException(const char* msg = "Poison") : uBaseException(msg) { }
    
    PoisonException(const PoisonException &other) : uBaseException(other.message()) { }
    
    ~PoisonException() { }
};

// ====================================================================
// BoundedBuffer
// ====================================================================

#ifdef BUSY

template<typename T>
class BoundedBuffer {
public:
    
    PoisonException Poison;
    
    BoundedBuffer(const unsigned int size = 10)
      : capacity(size), count(0), head(0), tail(0),
        blockCount(0), isPoisoned(false)
    {
        buffer = new T[capacity];
    }
    ~BoundedBuffer() { delete [] buffer; }

    unsigned long int blocks() { return blockCount; }

    void poison() {
        owner.acquire();
        isPoisoned = true;
        
        notEmpty.signal();
        notFull.signal();
        owner.release();
    }

    void insert(T elem) {
        owner.acquire();
        
        while (count == capacity) {
            blockCount++;
            if (isPoisoned) {
            notFull.signal();
            owner.release();
            throw Poison;
        }
            notFull.wait(owner);
        }
        assert(count < capacity);
        buffer[tail] = elem;
        tail = (tail + 1) % capacity;
        count++;
        
        notEmpty.signal();
        owner.release();
    }

    T remove() __attribute__((warn_unused_result)) {
        owner.acquire();
        
        while (count == 0) {
            if (isPoisoned) {
                notEmpty.signal();
                owner.release();
                throw Poison;
            }
            blockCount++;
            notEmpty.wait(owner);
        }
        assert(count > 0);
        T elem = buffer[head];
        head = (head + 1) % capacity;
        count--;
        
        notFull.signal();
        owner.release();
        return elem;
    }

private:
    T* buffer;                   // circular buffer array
    const unsigned int capacity; // buffer size
    unsigned int count;          // current number of elements
    unsigned int head;           // read position
    unsigned int tail;           // write position
    unsigned long int blockCount;// block count statistics
    bool isPoisoned;             // flag to mark if poisoned
    uOwnerLock owner;            // mutex lock
    uCondLock notFull;           // condition variable: buffer not full
    uCondLock notEmpty;          // condition variable: buffer not empty
};

#elif defined(NOBUSY)
      
template<typename T>
class BoundedBuffer {
public:
    PoisonException Poison;

    BoundedBuffer(const unsigned int size = 10)
      : capacity(size), count(0), head(0), tail(0),
        blockCount(0), isPoisoned(false), signalling(false)
    {
        buffer = new T[capacity];
    }
    ~BoundedBuffer() { delete [] buffer; }

    unsigned long int blocks() { return blockCount; }

    void poison() {
        owner.acquire();
        isPoisoned = true;
        notEmpty.signal(); // use signalAll
        notFull.signal();   // use signalAll
        owner.release();
    }

    void insert(T elem) {
        owner.acquire();
        PROD_ENTER;
        blockCount++;       // increment before wait
        while (count == capacity) {
              if (isPoisoned) {
                notFull.signal();
                owner.release();
                throw Poison;
            }
            if(signalling){ // if other threads are waiting, new threads join wait
                waitInsert.wait(owner);
            }else{
                notFull.wait(owner);
            }
        }
        blockCount--;       // decrement after wait, before insertion
        assert(count < capacity);

        buffer[tail] = elem;
        tail = (tail + 1) % capacity;
        count++;
        INSERT_DONE;

        if(waitRemove.signal()){
            signalling = true; // if consumer thread is woken, set flag
        }else{
            CONS_SIGNAL(notEmpty);
            notEmpty.signal();  // wake up one
        }

        owner.release();
    }
    T remove() __attribute__((warn_unused_result)) {
        owner.acquire();
        CONS_ENTER;
        blockCount++;         // increment before wait

        while (count == 0) {
            if (isPoisoned) {
                notEmpty.signal(); // wake all
                owner.release();
                throw Poison;
            }
             if(signalling){ // if other threads are waiting, new threads join wait
                waitRemove.wait(owner);
            }else{
               notEmpty.wait(owner);
            }
        }
        blockCount--; // decrement after wait, before removal
        assert(count > 0);
        T elem = buffer[head];
        head = (head + 1) % capacity;
        count--;
        REMOVE_DONE;

        if(waitInsert.signal()){
            signalling = true;
        } else{
            PROD_SIGNAL(notFull);
            notFull.signal();  // wake up one
        }

        owner.release();
        return elem;
    }
private:
    T* buffer;
    const unsigned int capacity;
    unsigned int count;
    unsigned int head;
    unsigned int tail;
    unsigned long int blockCount;
    bool isPoisoned;
    bool signalling; // added flag to indicate waiting threads
    uOwnerLock owner;
    uCondLock notFull;
    uCondLock notEmpty;
    uCondLock waitInsert; // condition variable for barging producers
    uCondLock waitRemove; // condition variable for barging consumers
    BCHECK_DECL;
};

#else
#error "Either BUSY or NOBUSY must be defined."
#endif

// ====================================================================
// Producer & Consumer tasks (Note: task main must be private)
// ====================================================================

_Task Producer {
    BoundedBuffer<int>& buffer;
    int produceCount;
    int delay;
    void main();  // main is private
public:
    Producer(BoundedBuffer<int>& buffer, int Produce, int Delay)
      : buffer(buffer), produceCount(Produce), delay(Delay) {}
};

void Producer::main() {
    for (int i = 1; i <= produceCount; i++) {
        int r = random() % delay;  // use C++ built-in random
        yield(r);
        buffer.insert(i);
    }
}

_Task Consumer {
    BoundedBuffer<int>& buffer;
    int delay;
    int &sum;
    void main();  // main is private
public:
    Consumer(BoundedBuffer<int>& buffer, int Delay, int &sum)
      : buffer(buffer), delay(Delay), sum(sum) {}
};

void Consumer::main() {
    sum = 0;
    while (true) {
        try {
            int r = random() % delay;
            yield(r);
            int value = buffer.remove();
            sum += value;
        } catch (const PoisonException &e) { // catch PoisonException
            break;
        }
    }
}

// ====================================================================
// Main program (entry point, uCpp_main for some versions)
// ====================================================================

int main(int argc, char* argv[]) {
    char * nosummary = getenv( "NOSUMMARY" );    // print heap stats?
    int cons = 5;         // default number of consumers
    int prods = 3;        // default number of producers
    int produce = 10;     // numbers per producer
    int buffersize = 10;  // buffer size
    int delay = cons + prods; // yield delay
    int processors = 1;   // parallel kernel threads

    // Adjust via command line (order: cons prods produce buffersize delay processors)
    if (argc > 1) cons = std::atoi(argv[1]);
    if (argc > 2) prods = std::atoi(argv[2]);
    if (argc > 3) produce = std::atoi(argv[3]);
    if (argc > 4) buffersize = std::atoi(argv[4]);
    if (argc > 5) delay = std::atoi(argv[5]);
    if (argc > 6) processors = std::atoi(argv[6]);

    if (cons <= 0 || prods <= 0 || produce <= 0 || buffersize <= 0 ||
        delay <= 0 || processors <= 0) {
        std::cerr << "Usage: " << argv[0]
                  << " [cons prods produce buffersize delay processors]" << std::endl;
        std::exit(EXIT_FAILURE);
    }

    // Create additional kernel threads (main thread exists)
    uProcessor p[processors - 1] __attribute__(( unused ));;

    // Create bounded buffer
    BoundedBuffer<int> buffer(buffersize);

    // Allocate sum variables for consumers
    int *consumerSums = new int[cons];
    Producer **producers = new Producer*[prods];
    Consumer **consumers = new Consumer*[cons];

    // Create consumer tasks
    for (int i = 0; i < cons; i++) {
        consumers[i] = new Consumer(buffer, delay, consumerSums[i]);
    }
    // Create producer tasks
    for (int i = 0; i < prods; i++) {
        producers[i] = new Producer(buffer, produce, delay);
    }

    // Wait for producers to finish (auto wait in destructor)
    for (int i = 0; i < prods; i++) {
        delete producers[i];
    }

    // After all producers finish, poison the buffer
    buffer.poison();

    // Wait for consumers to finish
    for (int i = 0; i < cons; i++) {
        delete consumers[i];
    }

    // Sum all partial results
    int total = 0;
    for (int i = 0; i < cons; i++) {
        total += consumerSums[i];
    }
    delete [] consumerSums;
    delete [] producers;
    delete [] consumers;
    
    std::cout << "total: " << total << std::endl;
    std::cout << "Total Producer/Consumer blocks in insert/remove " << buffer.blocks() << std::endl;
    if ( ! nosummary ) { malloc_stats(); }
    return 0;
}