#define _GNU_SOURCE
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/uio.h>

int main(void) {
    int fd = open("flag", O_RDONLY);
    if (fd < 0) {
        syscall(SYS_exit, 1);
    }
    
    char buf[128];
    ssize_t n = read(fd, buf, sizeof(buf) - 1);
    if (n < 0) {
        syscall(SYS_exit, 1);
    }
    close(fd);
    
    
    buf[n] = '\0';
    
    //  writev 
    struct iovec iov;
    iov.iov_base = buf;
    iov.iov_len = n;
    
    if (writev(1, &iov, 1) != n) {
        syscall(SYS_exit, 1);
    }
    
    syscall(SYS_exit, 0);
}
