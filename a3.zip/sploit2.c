// minimal_syscall.c
#define SYS_open         2
#define SYS_read         0
#define SYS_write        1
#define SYS_close        3
#define SYS_exit_group   231

// syscall 
static inline long my_syscall(long num, long arg1, long arg2, long arg3) {
    long ret;
    __asm__ volatile (
        "syscall"
        : "=a"(ret)
        : "a"(num), "D"(arg1), "S"(arg2), "d"(arg3)
        : "rcx", "r11", "memory"
    );
    return ret;
}


void _start(void) {
    int fd;
    char buf[256];
    long n;

    
    fd = my_syscall(SYS_open, (long)"flag", 0, 0);
    if (fd < 0)
        my_syscall(SYS_exit_group, 1, 0, 0);

    
    n = my_syscall(SYS_read, fd, (long)buf, sizeof(buf));
    if (n > 0)
        
        my_syscall(SYS_write, 1, (long)buf, n);

    
    my_syscall(SYS_close, fd, 0, 0);
    
    my_syscall(SYS_exit_group, 0, 0, 0);
}
