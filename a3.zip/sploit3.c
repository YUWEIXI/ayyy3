#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define BUF_SIZE 1024

int main() {
    
    int fd = open("flag", O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    char buf[BUF_SIZE];
    ssize_t n;

    
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        if (write(STDOUT_FILENO, buf, n) != n) {
            perror("write");
            close(fd);
            exit(EXIT_FAILURE);
        }
    }
    if (n < 0) {
        perror("read");
        close(fd);
        exit(EXIT_FAILURE);
    }
    close(fd);
    return 0;
}
