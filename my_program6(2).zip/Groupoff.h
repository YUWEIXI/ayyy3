// Groupoff.h
#ifndef GROUPOFF_H
#define GROUPOFF_H

#include <uC++.h>
#include <vector>
#include <future> 
#include <memory> 
#include "WATCard.h"

_Monitor Printer;

_Task Groupoff {
    Printer &prt;
    unsigned int numStudents;
    unsigned int sodaCost;
    unsigned int groupoffDelay;

    struct GiftCardRequest {
        std::promise<WATCard *> promise; 
        bool assigned;

        GiftCardRequest() : assigned(false) {}

        WATCard::FWATCard get_future_card() {
            return promise.get_future();
        }
    };
    std::vector<GiftCardRequest> requests;

    unsigned int cardsAssigned;
    void main();
    
  public:
        WATCard::FWATCard giftCard( unsigned int id ); 

  public:
    Groupoff( Printer &prt, unsigned int numStudents, unsigned int sodaCost, unsigned int groupoffDelay );
    ~Groupoff();
};

#endif // GROUPOFF_H
