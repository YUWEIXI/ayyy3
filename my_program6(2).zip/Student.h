// Student.h
#ifndef STUDENT_H
#define STUDENT_H

#include <uC++.h>
#include "Types.h"

#include "Printer.h"
#include "WATCard.h"
_Task NameServer;
_Task WATCardOffice;
_Task Groupoff;
_Task VendingMachine;

_Task Student {
    Printer &prt;
    NameServer *nameServer;
    WATCardOffice *cardOffice;
    Groupoff *groupoff; 
    unsigned int id;
    unsigned int maxPurchases;
    unsigned int seed;

    unsigned int numToPurchase;
    Flavours favouriteFlavour;
    VendingMachine *currentMachine;
    WATCard *watCard;
    WATCard::FWATCard watCardFuture;
    WATCard *giftCard; 
    WATCard::FWATCard giftCardFuture; 

    void main();

  public:
    Student( Printer &prt, NameServer *nameServer, WATCardOffice *cardOffice, Groupoff *groupoff,
             unsigned int id, unsigned int maxPurchases, unsigned int seed);
};

#endif // STUDENT_H
