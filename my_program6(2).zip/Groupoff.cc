// Groupoff.cc
#include "Groupoff.h"
#include "Printer.h"
#include <vector>
#include <stdexcept> 

Groupoff::Groupoff( Printer &prt, unsigned int numStudents, unsigned int sodaCost, unsigned int groupoffDelay ) :
    prt(prt), numStudents(numStudents), sodaCost(sodaCost), groupoffDelay(groupoffDelay),
    requests(numStudents),
    cardsAssigned(0) {
    prt.print(Printer::Groupoff, 'S');
}

Groupoff::~Groupoff() {
    prt.print(Printer::Groupoff, 'F');
}

void Groupoff::main() {
     try {
        for (;;) { 
            _Accept(~Groupoff) {
                break; 
            } or _Accept(giftCard) {
                 
            }
            _Else {
                if (cardsAssigned < numStudents) {
                    yield(groupoffDelay); 
                     _Accept(~Groupoff) {
                        break; 
                     } _Else {
                         unsigned int studentIdx;
                         unsigned int attempts = 0;
                         const unsigned int MAX_ATTEMPTS = numStudents * 5;
                         do {
                             studentIdx = prng(numStudents);
                             attempts++;
                             if (attempts > MAX_ATTEMPTS) {
                                 goto END_GROUPOFF_LOOP;
                             }
                         } while (requests[studentIdx].assigned);
                         WATCard *newCard = new WATCard();
                         newCard->deposit(sodaCost);
                         requests[studentIdx].promise.set_value(newCard);
                         requests[studentIdx].assigned = true;
                         cardsAssigned++;
                         prt.print(Printer::Groupoff, 'D', studentIdx, sodaCost);
                     } 
                } 
            } 
        } 
    END_GROUPOFF_LOOP:;
    } catch (...) {
         std::cerr << "Groupoff: Caught exception in main." << std::endl;
    }
}

WATCard::FWATCard Groupoff::giftCard( unsigned int id ) {
     if (id < requests.size()) {
        return requests[id].get_future_card();
    } else {
        std::promise<WATCard *> p;
        p.set_exception(std::make_exception_ptr(std::runtime_error("Invalid student ID for giftCard")));
        return p.get_future();
    }
}
