#include "Printer.h"
#include <iomanip>
using namespace std;

unsigned int Printer::getIndex(Kind kind, unsigned int lid)
{
  unsigned int index = 0;
    switch (kind) {
    case Student:
        index = 6 + lid;
        break;
    case Vending:
        index = 6 + numStudents + lid;
        break;
    case Courier:
        index = 6 + numStudents + numVendingMachines + lid;
        break;
    default:
        index = kind;
        break;
    }
    return index;
}

Printer::Printer( unsigned int numStudents, unsigned int numVendingMachines,
                 unsigned int numCouriers)
    : numStudents(numStudents), numVendingMachines(numVendingMachines),
      numCouriers(numCouriers) {
    objectNum = 6 + numStudents + numVendingMachines + numCouriers;
    printerInfos = new PrinterInfo[objectNum];
    cout << "Parent\t"
         << "Gropoff\t"
         << "WATOff\t"
         << "Names\t"
         << "Truck\t"
         << "Plant\t";
    for (unsigned int i = 0; i < numStudents; i++) {
        cout << "Stud" << i << "\t";
    }
    for (unsigned int i = 0; i < numVendingMachines; i++) {
        cout << "Mach" << i << "\t";
    }
    for (unsigned int i = 0; i < numCouriers; i++) {
        cout << "Cour" << i;
        if (i != numCouriers - 1) {
            cout << "\t"; 
        }
    }
    cout << endl; // 换行
    for (unsigned int i = 0; i < objectNum; i++) {
        cout << "*******";
        if (i != objectNum - 1) {
            cout << "\t"; 
        }
    }
    cout << endl;
}

void Printer::flush() {
    bool somethingToPrint = false;
    for (unsigned int i = 0; i < objectNum; ++i) {
        if (printerInfos[i].isSet) {
            somethingToPrint = true;
            break;
        }
    }
    if (!somethingToPrint) return;

    std::stringstream ss;
    for (unsigned int i = 0; i < objectNum; ++i) {
        if (printerInfos[i].isSet) {
            ss << printerInfos[i].state;
            if (printerInfos[i].num_values == 1) {
                ss << " " << printerInfos[i].value1; 
            } else if (printerInfos[i].num_values == 2) {
                ss << " " << printerInfos[i].value1 << "," << printerInfos[i].value2; 
            }
            printerInfos[i].isSet = false;
            printerInfos[i].num_values = 0;
        }
        if (i != objectNum - 1) {
            ss << "\t";
        }
    }
    std::cout << ss.str() << std::endl;
}

Printer::~Printer() {
    flush();
    cout << "***********************" << endl;
    delete[] printerInfos;
}
void Printer::print(Kind kind, char state) {
    unsigned int index = getIndex(kind, 0);
    if (printerInfos[index].isSet) flush(); 
    printerInfos[index].isSet = true;
    printerInfos[index].state = state;
    printerInfos[index].num_values = 0; 
}

void Printer::print(Kind kind, char state, unsigned int value1) {
    // flush();
    unsigned int index = getIndex(kind, 0);
     if (printerInfos[index].isSet) flush();
    printerInfos[index].isSet = true;
    printerInfos[index].state = state;
    printerInfos[index].value1 = value1;
    printerInfos[index].num_values = 1; 
}

void Printer::print(Kind kind, char state, unsigned int value1, unsigned int value2) {
    // flush();
    unsigned int index = getIndex(kind, 0);
     if (printerInfos[index].isSet) flush();
    printerInfos[index].isSet = true;
    printerInfos[index].state = state;
    printerInfos[index].value1 = value1;
    printerInfos[index].value2 = value2;
    printerInfos[index].num_values = 2; 
}

void Printer::print(Kind kind, unsigned int lid, char state) {
    // flush();
    unsigned int index = getIndex(kind, lid);
     if (printerInfos[index].isSet) flush();
    printerInfos[index].isSet = true;
    printerInfos[index].state = state;
    printerInfos[index].num_values = 0;
}

void Printer::print(Kind kind, unsigned int lid, char state, unsigned int value1) {
    // flush();
    unsigned int index = getIndex(kind, lid);
     if (printerInfos[index].isSet) flush();
    printerInfos[index].isSet = true;
    printerInfos[index].state = state;
    printerInfos[index].value1 = value1;
    printerInfos[index].num_values = 1;
}

void Printer::print(Kind kind, unsigned int lid, char state, unsigned int value1, unsigned int value2) {
    // flush();
    unsigned int index = getIndex(kind, lid);
     if (printerInfos[index].isSet) flush();
    printerInfos[index].isSet = true;
    printerInfos[index].state = state;
    printerInfos[index].value1 = value1;
    printerInfos[index].value2 = value2;
    printerInfos[index].num_values = 2;
}
