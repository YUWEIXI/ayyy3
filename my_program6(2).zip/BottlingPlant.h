// BottlingPlant.h
#ifndef BOTTLINGPLANT_H
#define BOTTLINGPLANT_H

#include <uC++.h>
#include "Types.h"

_Monitor Printer;
_Task NameServer;
_Task Truck;

_Task BottlingPlant {
    Printer &prt;
    NameServer &nameServer;
    unsigned int numVendingMachines;
    unsigned int maxShippedPerFlavour;
    unsigned int maxStockPerFlavour;
    unsigned int timeBetweenShipments;
    public : Truck *truck;
             bool plantClosing;
    private: unsigned int productionRun[NUM_OF_FLAVOURS];
    public: bool flag;
            
    private: bool shipmentReady;
    
    void main();

  public:
    BottlingPlant( Printer &prt, NameServer &nameServer, unsigned int numVendingMachines,
                   unsigned int maxShippedPerFlavour, unsigned int maxStockPerFlavour,
                   unsigned int timeBetweenShipments );
    ~BottlingPlant();
    void getShipment( unsigned int cargo[] );
    _Exception Shutdown {
        public:
            Shutdown(){}
    };
};

#endif 
