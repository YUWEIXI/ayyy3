// Student.cc
#include "Student.h"
#include "Printer.h"
#include "NameServer.h"
#include "VendingMachine.h"
#include "WATCardOffice.h"
#include "WATCard.h"
#include "Groupoff.h"   
#include "Types.h"
#include <future>       
#include <exception>    
#include <stdexcept>    

Student::Student( Printer &prt, NameServer *nameServer, WATCardOffice *cardOffice, Groupoff *groupoff,
                  unsigned int id, unsigned int maxPurchases , unsigned int seed ) :
    prt(prt), nameServer(nameServer), cardOffice(cardOffice), groupoff(groupoff),
    id(id), maxPurchases(maxPurchases), seed(seed), currentMachine(nullptr), watCard(nullptr), giftCard(nullptr) {
    set_seed(seed);
}

void Student::main() {
    unsigned int bottlesPurchased = 0; 
    unsigned int freeSodas = 0; // 记录免费汽水数量
    WATCard *watCard = nullptr;
    WATCard *giftCard = nullptr;
    VendingMachine *currentMachine = nullptr;
    WATCard::FWATCard watCardFuture;
    WATCard::FWATCard giftCardFuture;
    bool flag = 0;

    numToPurchase = prng(maxPurchases) + 1;
    favouriteFlavour = (Flavours)prng(NUM_OF_FLAVOURS);
    prt.print(Printer::Student, id, 'S', favouriteFlavour, numToPurchase);
    
    
    if (cardOffice == nullptr) {
        prt.print(Printer::Student, id, 'X');
        goto END_STUDENT; 
    }
    watCardFuture = cardOffice->create(id, 5); 
    
    if (groupoff != nullptr) {
        giftCardFuture = groupoff->giftCard(id);
    }
    
    if (nameServer == nullptr) {
         prt.print(Printer::Student, id, 'V', 999);
         goto END_STUDENT; 
    }
    currentMachine = nameServer->getMachine(id);
    if (currentMachine == nullptr) {
         prt.print(Printer::Student, id, 'V', 999);
         goto END_STUDENT; 
    }
    prt.print(Printer::Student, id, 'V', currentMachine->getId());
    
    while (bottlesPurchased < numToPurchase) {
        yield(prng(1, 10));

        const unsigned int MAX_STOCK_CHECK_ATTEMPTS = 20;
        unsigned int stockCheckAttempts = 0;
        bool purchased_this_bottle = false;

        while (!purchased_this_bottle && stockCheckAttempts < MAX_STOCK_CHECK_ATTEMPTS) {

             if (!currentMachine) {
                 prt.print(Printer::Student, id, 'X');
                 goto END_STUDENT;
             }
            try {
                if (watCard == nullptr && watCardFuture.valid()) {
                    try {
                        watCard = watCardFuture.get();
                        // std::cout << "AFTER GET (WATCard): Student " << id << " future.get() successful..." << std::endl;
                    } catch (const WATCardOffice::Lost &) {
                        // std::cout << "Student " << id << " caught Lost..." << std::endl;
                        prt.print(Printer::Student, id, 'L');
                        if (cardOffice) watCardFuture = cardOffice->create(id, 5);
                        goto NEXT_PURCHASE_ATTEMPT; 
                    } catch (...) { goto END_STUDENT; } 
                }

                if (giftCard == nullptr && giftCardFuture.valid()) {
                     try {
                         giftCard = giftCardFuture.get();
                     } catch (...) {
                         
                     }
                }
                if (watCard == nullptr && cardOffice != nullptr && !watCardFuture.valid()) {
                     prt.print(Printer::Student, id, 'X');
                     goto END_STUDENT;
                }
                unsigned int cost = currentMachine->cost();
                WATCard *cardToUse = nullptr;

                if (giftCard != nullptr) {
                    cardToUse = giftCard;
                    flag = 1;
                    
                } else if (watCard != nullptr) {
                    cardToUse = watCard;
                    flag = 0;
                } else {
                    watCardFuture = cardOffice->transfer(id, cost + 5, watCard);
                    watCard = nullptr; 
                }

                if (cardToUse == nullptr) {
                     goto NEXT_PURCHASE_ATTEMPT; 
                }

                try {
                    currentMachine->buy(favouriteFlavour, *cardToUse);
                    if(flag == 1) prt.print(Printer::Student, id, 'G', favouriteFlavour, giftCard->getBalance()); 
                    else prt.print(Printer::Student, id, 'B', favouriteFlavour, watCard->getBalance()); 
                    purchased_this_bottle = true;
                    bottlesPurchased++;

                    if (cardToUse == giftCard) {
                        delete giftCard; 
                        giftCard = nullptr; 
                    }

                } catch (Stock &) {
                    // std::cout << "Machine Out of Stock" << std::endl;
                    
                    stockCheckAttempts++;
                    // std::cout << "stockCheckAttempts : " << stockCheckAttempts << std::endl;
                    if (nameServer) {
                        currentMachine = nameServer->getMachine(id);
                        if (currentMachine) {
                            // std::cout << "student" << id << "select Machine " << currentMachine->getId() << std::endl;
                            prt.print(Printer::Student, id, 'V', currentMachine->getId());
                        } else {
                            prt.print(Printer::Student, id, 'V', 999);
                            goto END_STUDENT;
                        }
                    } else { goto END_STUDENT; }

                } catch (Free &) {
                    prt.print(Printer::Student, id, 'A', favouriteFlavour);
                    // std::cout << "watch ad" << std::endl;
                    yield(4); // Watch ad
                    purchased_this_bottle = true;
                    bottlesPurchased++;
                    freeSodas++; 
                }catch(Funds &){
                    // std::cerr << "Student " << id << " caught unexpected Funds exception! Requesting transfer." << std::endl; // 添加错误日志
                    if (cardOffice && watCard) { 
                        unsigned int cost = currentMachine->cost(); 
                        watCardFuture = cardOffice->transfer(id, cost + 5, watCard);
                        watCard = nullptr; 
                    }
                }

            } catch (...) { 
                 prt.print(Printer::Student, id, 'X');
                 goto END_STUDENT;
            } 

        NEXT_PURCHASE_ATTEMPT:; 
        } 

        if (!purchased_this_bottle) {
             goto END_STUDENT;
        }

    }

END_STUDENT:
    prt.print(Printer::Student, id, 'F', bottlesPurchased, freeSodas);
    try { 
        delete giftCard;
    } catch (...) {
        std::cerr << "Student " << id << ": Exception while deleting giftCard!" << std::endl;
    }
    delete watCard;
}
