// WATCardOffice.h
#ifndef WATCARDOFFICE_H
#define WATCARDOFFICE_H

#include <uC++.h>
#include <vector>
#include <queue>
#include <future> 
#include <memory> 
#include "WATCard.h"

_Monitor Printer;
_Monitor Bank;

_Task WATCardOffice {
    struct Args {
        unsigned int studentId;
        unsigned int amount;
        WATCard *card;
        enum JobType { CREATE, TRANSFER } type;
        Args(unsigned int sid, unsigned int amount, JobType type, WATCard *card = nullptr) :
            studentId(sid), amount(amount), card(card), type(type) {}
    };

    struct Job {
        Args args; 
        std::promise<WATCard *> promise;
        Job( Args args ) : args( args ) {} 

        WATCard::FWATCard get_future_result() {
            return promise.get_future();
        }
        ~Job() { /* ... */ }
    };

    _Task Courier { /* ... */
      public:
        WATCardOffice &office;
        Printer &prt;
        Bank &bank;
        unsigned int id;
      private: void main();
      public:
        Courier(WATCardOffice &office, Printer &prt, Bank &bank, unsigned int id);
     };

    Printer &prt;
    Bank &bank;
    unsigned int numCouriers;
    std::vector<Courier*> couriers;
    std::queue<Job*> jobQueue;
    uCondition jobAvailableCond;
    bool officeClosing;
    void main();

  public:
    _Exception Lost {};

    WATCardOffice( Printer &prt, Bank &bank, unsigned int numCouriers );
    ~WATCardOffice();
    WATCard::FWATCard create( unsigned int sid, unsigned int amount );
    WATCard::FWATCard transfer( unsigned int sid, unsigned int amount, WATCard *card );
    Job *requestWork();
};

#endif 
