// Printer.h
#ifndef PRINTER_H
#define PRINTER_H

#include <uC++.h>
#include <iostream>

_Monitor Printer {
  public:
    enum Kind {
        Parent,
        Groupoff,
        WATCardOffice,
        NameServer,
        Truck,
        BottlingPlant,
        Student,
        Vending,
        Courier
    };

    Printer( unsigned int numStudents, unsigned int numVendingMachines, unsigned int numCouriers );
    ~Printer();
    void print( Kind kind, char state );
    void print( Kind kind, char state, unsigned int value1 );
    void print( Kind kind, char state, unsigned int value1, unsigned int value2 );
    void print( Kind kind, unsigned int lid, char state );
    void print( Kind kind, unsigned int lid, char state, unsigned int value1 );
    void print( Kind kind, unsigned int lid, char state, unsigned int value1, unsigned int value2 );

private:
    struct PrinterInfo {
        bool isSet = false;
        char state;
        unsigned int value1; 
        unsigned int value2;
        unsigned int num_values = 0; 
    };

    PrinterInfo *printerInfos;       
    unsigned int numStudents;         
    unsigned int numVendingMachines; 
    unsigned int numCouriers;        
    unsigned int objectNum;          

    void flush();                    
    unsigned int getIndex(Kind kind, unsigned int lid); 
};

#endif
