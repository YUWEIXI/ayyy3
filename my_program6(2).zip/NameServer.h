// NameServer.h
#ifndef NAMESERVER_H
#define NAMESERVER_H

#include <uC++.h>
#include <vector>

_Monitor Printer;
_Task VendingMachine;

_Task NameServer {
    Printer &prt;
    unsigned int numVendingMachines;
    unsigned int numStudents;

    std::vector<VendingMachine*> machineList;
    std::vector<unsigned int> studentNextMachine;

    void main();

  public:
    NameServer( Printer &prt, unsigned int numVendingMachines, unsigned int numStudents );
    ~NameServer();

    void VMregister( VendingMachine *vendingmachine );
    VendingMachine *getMachine( unsigned int id );
    VendingMachine **getMachineList();
};

#endif // NAMESERVER_H
