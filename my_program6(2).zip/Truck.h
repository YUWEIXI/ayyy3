// Truck.h
#ifndef TRUCK_H
#define TRUCK_H

#include <uC++.h>
#include "Types.h" 

// Forward Declarations
_Monitor Printer;
_Task NameServer;
_Task BottlingPlant; 

_Task Truck {
    Printer &prt;
    NameServer &nameServer;
    BottlingPlant &plant;
    unsigned int numVendingMachines;
    unsigned int maxStockPerFlavour;
    
    unsigned int cargo[NUM_OF_FLAVOURS]; 
    unsigned int totalCargo;

    void main();
    

  public:
    Truck( Printer &prt, NameServer &nameServer, BottlingPlant &plant,
           unsigned int numVendingMachines, unsigned int maxStockPerFlavour);
    ~Truck();
    // bool mustShutdown; 
    //void waitForCompletion() { doneCond.wait(); }
    //uCondition &doneCond;
    //bool &plantClosing;
};

#endif // TRUCK_H
