// VendingMachine.h
#ifndef VENDINGMACHINE_H
#define VENDINGMACHINE_H

#include <uC++.h>
#include "Types.h"
#include "NameServer.h" 

_Event Funds {};
_Event Stock {};
_Event Free {};
_Monitor Printer;
class WATCard;

_Task VendingMachine {
    Printer &prt;
    NameServer *nameServer; 
    unsigned int id;
    unsigned int sodaCost;
    unsigned int maxStockPerFlavour;

    unsigned int stock[NUM_OF_FLAVOURS];
    bool restocking;
    uCondition restockingCond;

    void main();

  public:
    VendingMachine( Printer &prt, NameServer *nameServer, unsigned int id, unsigned int sodaCost, unsigned int maxStockPerFlavour );
    ~VendingMachine();

    void buy( Flavours flavour, WATCard &card );
    unsigned int *inventory();
    void restocked();
    unsigned int cost() const _Nomutex;
    unsigned int getId() const _Nomutex;
};

#endif 
