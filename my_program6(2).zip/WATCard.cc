// WATCard.cc
#include "WATCard.h"
#include <stdexcept>
#include <cstdlib> 
#include <cstdio>  

WATCard::WATCard() : balance(0) {}

void WATCard::deposit( unsigned int amount ) {
    balance += amount;
}

void WATCard::withdraw( unsigned int amount ) {
    if (balance < amount) {
         fprintf(stderr, "Error: WATCard withdrawal amount %u exceeds balance %u. Should have been checked.\n", amount, balance);
         abort(); 
    }
    balance -= amount;
}

unsigned int WATCard::getBalance() {
    return balance;
}
