// WATCardOffice.cc
#include "WATCardOffice.h"
#include "Printer.h"
#include "Bank.h"
#include <future> 
#include <queue>

WATCardOffice::Courier::Courier(WATCardOffice &office, Printer &prt, Bank &bank, unsigned int id) :
    office(office), prt(prt), bank(bank), id(id) {}

void WATCardOffice::Courier::main() {
    prt.print(Printer::Courier, id, 'S');
    try { 
        for (;;) {
            Job *job = office.requestWork();
            if (job == nullptr) break;

            unsigned int studentIdForJob = job->args.studentId;
            unsigned int amountForJob = job->args.amount;

            // t s,a: start funds transfer - OK
            prt.print(Printer::Courier, id, 't', studentIdForJob, amountForJob);

            bank.withdraw(studentIdForJob, amountForJob); 

            if (job->args.type == Args::CREATE) { job->args.card = new WATCard(); }
            job->args.card->deposit(amountForJob); 

            if (prng(6) == 0) { 
                try { job->promise.set_exception(std::make_exception_ptr(Lost())); } catch (...) { /*...*/ delete job->args.card; delete job; continue; }
                delete job->args.card;
                prt.print(Printer::Courier, id, 'L', studentIdForJob);
            } else { 
                try { job->promise.set_value(job->args.card); } catch (...) { /*...*/ delete job->args.card; delete job; continue; }
                prt.print(Printer::Courier, id, 'T', studentIdForJob, amountForJob);
            }
            delete job;
        }
    } catch (uMutexFailure::RendezvousFailure &) {
         std::cerr << "Courier " << id << " caught RendezvousFailure" << std::endl;
    }
    catch (...) {
         std::cerr << "Courier " << id << " caught unknown exception" << std::endl;
    }
    prt.print(Printer::Courier, id, 'F');
}

WATCardOffice::WATCardOffice( Printer &prt, Bank &bank, unsigned int numCouriers ) :
    prt(prt), bank(bank), numCouriers(numCouriers), officeClosing(false) {
    prt.print(Printer::WATCardOffice, 'S');
    couriers.reserve(numCouriers);
    for (unsigned int i = 0; i < numCouriers; ++i) {
        couriers.push_back(new Courier(*this, prt, bank, i));
    }
}

WATCardOffice::~WATCardOffice() {
    officeClosing = true;
    jobAvailableCond.signalBlock();
    for (Courier *courier : couriers) {
        delete courier;
    }
    prt.print(Printer::WATCardOffice, 'F');
}

void WATCardOffice::main() {
    for (;;) {
         _Accept(~WATCardOffice) {
            break;
        } or _Accept(create) {
             
        } or _Accept(transfer) {
             
        } or _Accept(requestWork) {
              prt.print(Printer::WATCardOffice, 'W');
        }
    }
}

WATCard::FWATCard WATCardOffice::create( unsigned int sid, unsigned int amount ) {
    Args args(sid, amount, Args::CREATE);
    Job *newJob = new Job(args); 
    jobQueue.push(newJob);
    jobAvailableCond.signal();
    prt.print(Printer::WATCardOffice, 'C', newJob->args.studentId, newJob->args.amount);
    return newJob->get_future_result(); 
}

WATCard::FWATCard WATCardOffice::transfer( unsigned int sid, unsigned int amount, WATCard *card ) {
    Args args(sid, amount, Args::TRANSFER, card);
    Job *newJob = new Job(args);
    jobQueue.push(newJob);
    jobAvailableCond.signal();
    prt.print(Printer::WATCardOffice, 'T', newJob->args.studentId, newJob->args.amount);
    return newJob->get_future_result();
}

WATCardOffice::Job *WATCardOffice::requestWork() {
    while (jobQueue.empty() && !officeClosing) {
        jobAvailableCond.wait();
    }
    if (officeClosing && jobQueue.empty()) {
        jobAvailableCond.signal();
        return nullptr;
    }
    Job *job = jobQueue.front();
    jobQueue.pop();
    return job;
}
