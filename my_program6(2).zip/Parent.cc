// Parent.cc
#include "Parent.h"

Parent::Parent(Printer &prt, Bank &bank, unsigned int numStudents,
               unsigned int parentalDelay, unsigned int seed)
    : prt(prt), bank(bank), numStudents(numStudents),
      parentalDelay(parentalDelay), seed(seed) {
    set_seed(seed);
}

//Parent::~Parent() {
//}

void Parent::main() {
    prt.print(Printer::Parent, 'S');
    unsigned int totalDeposits = 0;

    for (;;) {
        _Accept(~Parent) { 
            break; 
        }
        _Else {
            yield(parentalDelay);

            unsigned int studentId = prng(numStudents);
            unsigned int amount = prng(3) + 1;

            bank.deposit(studentId, amount);
            prt.print(Printer::Parent, 'D', studentId, amount);
            totalDeposits += amount;
        }
    }
    prt.print(Printer::Parent, 'F', totalDeposits); 
}
