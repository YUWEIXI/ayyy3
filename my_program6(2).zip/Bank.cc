// Bank.cc
#include "Bank.h"
#include <stdexcept> 

Bank::Bank(unsigned int numStudents) :
    numStudents(numStudents),
    studentBalances(numStudents, 0), 
    sufficientFundsConds(numStudents) 
    {} 

Bank::~Bank() {
    //
}

void Bank::deposit(unsigned int id, unsigned int amount) {
    if (id >= numStudents) {
        throw std::out_of_range("Deposit: Student ID out of range");
    }
    studentBalances[id] += amount;
    sufficientFundsConds[id].signalBlock(); 
}

void Bank::withdraw(unsigned int id, unsigned int amount) {
    if (id >= numStudents) {
        throw std::out_of_range("Withdraw: Student ID out of range");
    }
    while (studentBalances[id] < amount) {
        sufficientFundsConds[id].wait();
    }
    studentBalances[id] -= amount;
}
