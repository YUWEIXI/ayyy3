// NameServer.cc
#include "NameServer.h"
#include "Printer.h"
#include "VendingMachine.h"

NameServer::NameServer( Printer &prt, unsigned int numVendingMachines, unsigned int numStudents ) :
    prt(prt), numVendingMachines(numVendingMachines), numStudents(numStudents),
    studentNextMachine(numStudents, 0) { 
    machineList.reserve(numVendingMachines);
}

NameServer::~NameServer() {
    prt.print(Printer::NameServer, 'F');
}

void NameServer::main() {
    prt.print(Printer::NameServer, 'S');
    for (unsigned int i = 0; i < numVendingMachines; ++i) {
         _Accept(VMregister);
    }
    try {
        for (;;) {
             _Accept(~NameServer) {
                break;
            } or _Accept(getMachine) {
            } or _Accept(getMachineList) {
            }
        }
    } catch (uMutexFailure::RendezvousFailure &) {
    }
}

void NameServer::VMregister( VendingMachine *vendingmachine ) {
     prt.print(Printer::NameServer, 'R', vendingmachine->getId());
     machineList.push_back(vendingmachine);
}

VendingMachine *NameServer::getMachine( unsigned int id ) {
    if (machineList.empty()) return nullptr;
    if (id >= studentNextMachine.size()) return nullptr;

    unsigned int idx = studentNextMachine[id];
    if (idx >= machineList.size()) return nullptr;
    VendingMachine* machine = machineList[idx];

    prt.print(Printer::NameServer, 'N', id, machine->getId());
    studentNextMachine[id] = (idx + 1) % machineList.size();

    return machine;
}

VendingMachine **NameServer::getMachineList() {
    if (machineList.empty()) { 
        return nullptr;
    }
    return machineList.data();
}
