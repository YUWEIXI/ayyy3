// WATCard.h
#ifndef WATCARD_H
#define WATCARD_H

#include <uC++.h>
#include <future> 

class WATCard {
    unsigned int balance;

    WATCard( const WATCard & ) = delete;
    WATCard & operator=( const WATCard & ) = delete;

  public:
    typedef std::future<WATCard *> FWATCard; 

    WATCard();
    void deposit( unsigned int amount );
    void withdraw( unsigned int amount ); 
    unsigned int getBalance();
};

#endif // WATCARD_H
