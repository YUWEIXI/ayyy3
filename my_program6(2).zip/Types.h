// Types.h
#ifndef TYPES_H
#define TYPES_H
#pragma once 

enum Flavours { BlueBlackCherry, ClassicCreamSoda, RockRootBeer, JazzLime, NUM_OF_FLAVOURS };

#endif
