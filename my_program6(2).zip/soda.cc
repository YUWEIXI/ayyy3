// soda.cc
#include <uC++.h>
#include <iostream>
#include <sstream>      
#include <string>
#include <vector>
#include <unistd.h>
#include <uFile.h>
#include <cstdlib>      

#include "config.h"
#include "Printer.h"
#include "Bank.h"
#include "Parent.h"
#include "Student.h"
#include "VendingMachine.h"
#include "NameServer.h"
#include "WATCardOffice.h"
#include "BottlingPlant.h"
#include "Groupoff.h"   
#include "Types.h"

int main(int argc, char *argv[]) { 

    const char *configFile = "soda.config";
    unsigned int seed = getpid(); 
    unsigned int processors = 1;
    std::stringstream ss;

    try { 
        switch (argc) {
            case 4:
                if (std::string(argv[3]) != "d") {
                    processors = std::stoi(argv[3]); 
                    if (processors <= 0) throw std::invalid_argument("processors must be > 0");
                }
            case 3:
                if (std::string(argv[2]) != "d") {
                    seed = std::stoi(argv[2]); 
                    if (seed <= 0) throw std::invalid_argument("seed must be > 0");
                }
            case 2:
                if (std::string(argv[1]) != "d") {
                    configFile = argv[1];
                }
                break;
            case 1:
                break; // Use defaults
            default:
                throw std::invalid_argument("Incorrect number of arguments");
        }
        if (processors <= 0) throw std::invalid_argument("processors must be > 0"); 
        if (seed <= 0) throw std::invalid_argument("seed must be > 0");

    } catch (const std::invalid_argument& e) {
        std::cerr << "Usage: " << argv[0] << " [ configFile | 'd' [ seed (> 0) | 'd' [ processors (> 0) | 'd' ] ] ]" << std::endl;
        return 1;
    } catch (const std::out_of_range& e) { 
        std::cerr << "Error: Argument value out of range." << std::endl;
        std::cerr << "Usage: " << argv[0] << " [ configFile | 'd' [ seed (> 0) | 'd' [ processors (> 0) | 'd' ] ] ]" << std::endl;
        return 1;
    } catch (...) { 
        std::cerr << "Error parsing command line arguments." << std::endl;
        std::cerr << "Usage: " << argv[0] << " [ configFile | 'd' [ seed (> 0) | 'd' [ processors (> 0) | 'd' ] ] ]" << std::endl;
        return 1;
    }
    ConfigParms cparms;
    try {
        processConfigFile(configFile, cparms);
    } catch (const uFile::Failure&) { /* ... */ return 1;}
    catch (...) { /* ... */ return 1;}

    if (processors > 1) { uProcessor p[processors - 1]; }

    Printer printer(cparms.numStudents, cparms.numVendingMachines, cparms.numCouriers);
    Bank bank(cparms.numStudents);
    NameServer *nameServer = new NameServer(printer, cparms.numVendingMachines, cparms.numStudents);
    WATCardOffice *cardOffice = new WATCardOffice(printer, bank, cparms.numCouriers);
    Parent *parent = new Parent(printer, bank, cparms.numStudents, cparms.parentalDelay, seed);
    Groupoff *groupoff = new Groupoff(printer, cparms.numStudents, cparms.sodaCost, cparms.groupoffDelay);
    
    BottlingPlant *plant = new BottlingPlant(printer, *nameServer, cparms.numVendingMachines,
                                             cparms.maxShippedPerFlavour, cparms.maxStockPerFlavour,
                                             cparms.timeBetweenShipments);
    VendingMachine *vendingMachines[cparms.numVendingMachines];
    for (unsigned int i = 0; i < cparms.numVendingMachines; ++i) {
        vendingMachines[i] = new VendingMachine(printer, nameServer, i, cparms.sodaCost, cparms.maxStockPerFlavour);
    }
    Student *students[cparms.numStudents];
    for (unsigned int i = 0; i < cparms.numStudents; ++i) {
        students[i] = new Student(printer, nameServer, cardOffice, groupoff, i, cparms.maxPurchases, seed + i);
    }

    for (unsigned int i = 0; i < cparms.numStudents; ++i) { 
        delete students[i]; 
    }
    plant->plantClosing = true;
    delete plant;
    for (unsigned int i = 0; i < cparms.numVendingMachines; ++i) { delete vendingMachines[i]; }
    delete groupoff;
    delete parent;
    delete cardOffice;
    delete nameServer;
    return 0;
}
