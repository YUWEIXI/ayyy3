// Truck.cc
#include "Truck.h"
#include "Printer.h"
#include "NameServer.h"
#include "VendingMachine.h"
#include "BottlingPlant.h"
#include <numeric>
#include <algorithm> 
#include <iostream>

Truck::Truck( Printer &prt, NameServer &nameServer, BottlingPlant &plant,
              unsigned int numVendingMachines, unsigned int maxStockPerFlavour) :
    prt(prt), nameServer(nameServer), plant(plant),
    numVendingMachines(numVendingMachines), maxStockPerFlavour(maxStockPerFlavour),
    totalCargo(0) {
    // mustShutdown = false;
    for (unsigned int i = 0; i < NUM_OF_FLAVOURS; ++i) {
        cargo[i] = 0;
    }
    prt.print(Printer::Truck, 'S');
}

Truck::~Truck(){
    prt.print(Printer::Truck, 'F');
}

void Truck::main() {
    VendingMachine **machineList = nullptr;
    unsigned int lastStockedMachine = 0;
    
    while(true) {
        _Accept(~Truck){break;}
        _Else{
        yield(prng(1,11)); 
        if(plant.plantClosing == true) break;
        
        try {
            // yield(1);
            plant.getShipment(cargo); 
        } catch (BottlingPlant::Shutdown &) {
            // std::cout << "BottlingPlant::Shutdown" << std::endl;
            // mustShutdown = true;
            break;
        }
        totalCargo = std::accumulate(cargo, cargo + NUM_OF_FLAVOURS, 0u);
        prt.print(Printer::Truck, 'P', totalCargo);
        if (totalCargo == 0) {
             continue;
        }
        machineList = nameServer.getMachineList();
        if (machineList == nullptr || numVendingMachines == 0) {
            continue;
        }
        unsigned int machinesChecked = 0;
        while (totalCargo > 0 && machinesChecked < numVendingMachines) { 
            unsigned int currentMachineIndex = lastStockedMachine % numVendingMachines;
            VendingMachine *currentMachine = machineList[currentMachineIndex];
            unsigned int notReplenishedTotal = 0;
            unsigned int currentMachineId = currentMachine->getId();
            
            prt.print(Printer::Truck, 'd', currentMachineId, totalCargo);
            try { 
                unsigned int *machineInventory = currentMachine->inventory();
                for (unsigned int flavour = 0; flavour < NUM_OF_FLAVOURS; ++flavour) {
                    
                    unsigned int currentStock = machineInventory[flavour];
                    unsigned int canAddToMachine = maxStockPerFlavour - currentStock;
                    unsigned int amountToAdd = std::min(cargo[flavour], canAddToMachine);
                    if (cargo[flavour] > amountToAdd) { notReplenishedTotal += (cargo[flavour] - amountToAdd); }
                    if (amountToAdd > 0) {
                        machineInventory[flavour] += amountToAdd;
                        cargo[flavour] -= amountToAdd;
                        totalCargo -= amountToAdd;
                    }
                }
                if (notReplenishedTotal > 0) { prt.print(Printer::Truck, 'U', currentMachineId, notReplenishedTotal); }
                prt.print(Printer::Truck, 'D', currentMachineId, totalCargo);
                currentMachine->restocked();

            } catch (uMutexFailure::RendezvousFailure &) {
                 std::cerr << "Truck: RendezvousFailure with VM " << currentMachine->getId() << ". Assuming VM deleted." << std::endl;
                 break; 
            }
            lastStockedMachine = (currentMachineIndex + 1);
            machinesChecked++;

            if (prng(100) == 1) { 
              prt.print(Printer::Truck, 'W'); 
              yield(10); 
            }
        }
        }
        
        
    }
    // std::cout << "Truck finished" << std::endl;
    // mustShutdown = true;
    // *plant = NULL;
    // doneCond.signal();
    // plant->flag = true;
    // doneCond.signal();
}
