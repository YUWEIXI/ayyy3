// VendingMachine.cc
#include "VendingMachine.h"
#include "Printer.h"
#include "NameServer.h"
#include "WATCard.h"

VendingMachine::VendingMachine( Printer &prt, NameServer *nameServer, unsigned int id, unsigned int sodaCost, unsigned int maxStockPerFlavour ) :
    prt(prt), nameServer(nameServer), id(id), sodaCost(sodaCost), maxStockPerFlavour(maxStockPerFlavour), restocking(false) {
    for (unsigned int i = 0; i < NUM_OF_FLAVOURS; ++i) {
        stock[i] = 0;
    }
}

VendingMachine::~VendingMachine(){
    prt.print(Printer::Vending, id, 'F');
}

void VendingMachine::main() {
    prt.print(Printer::Vending, id, 'S', sodaCost);

    if (nameServer != nullptr) {
        nameServer->VMregister(this); 
    } else {
        prt.print(Printer::Vending, id, 'E', 999);
        return;
    }
    try {
        for (;;) {
            _Accept(~VendingMachine) {
                break;
            } or _Accept(buy) {
            } or _Accept(inventory) {
                 prt.print(Printer::Vending, id, 'r');
            } or _Accept(restocked) {
                 prt.print(Printer::Vending, id, 'R');
            }
        }
    } catch (uMutexFailure::RendezvousFailure &) {
    }
}

unsigned int* VendingMachine::inventory() {
    restocking = true;
    return stock;
}
void VendingMachine::restocked() {
    restocking = false;
    // std::cout << "restockingCond.signalBlock();" << std::endl;
    restockingCond.signalBlock();
}
unsigned int VendingMachine::cost() const _Nomutex {
    return sodaCost;
}
unsigned int VendingMachine::getId() const _Nomutex {
    return id;
}
void VendingMachine::buy( Flavours flavour, WATCard &card ) {
    if (restocking) {
        // std::cout << "restocking.wait()" << std::endl;
        restockingCond.wait();
        if (restocking) {
             _Throw Stock();
        }
    }
    if (stock[flavour] == 0) {
        // std::cout << "no stock" << std::endl;
        _Throw Stock();
    }
    if (card.getBalance() < sodaCost) {
        _Throw Funds();
    }
    if (prng(4) == 0) {
        stock[flavour] -= 1;
        prt.print(Printer::Vending, id, 'A');
        _Throw Free();
    }
    card.withdraw(sodaCost);
    stock[flavour] -= 1;
    prt.print(Printer::Vending, id, 'B', flavour, stock[flavour]);
}
