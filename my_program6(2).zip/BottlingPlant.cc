#include "BottlingPlant.h"
#include "Printer.h"
#include "NameServer.h"
#include "Truck.h"
#include <numeric>
#include <iostream>

BottlingPlant::BottlingPlant( Printer &prt, NameServer &nameServer, unsigned int numVendingMachines,
                              unsigned int maxShippedPerFlavour, unsigned int maxStockPerFlavour,
                              unsigned int timeBetweenShipments ) :
    prt(prt), nameServer(nameServer), numVendingMachines(numVendingMachines),
    maxShippedPerFlavour(maxShippedPerFlavour), maxStockPerFlavour(maxStockPerFlavour),
    timeBetweenShipments(timeBetweenShipments), plantClosing(false), shipmentReady(false) 
{
    for (unsigned int i = 0; i < NUM_OF_FLAVOURS; ++i) { productionRun[i] = 0; }
    prt.print(Printer::BottlingPlant, 'S');
    flag = false;
}


BottlingPlant::~BottlingPlant() {
    delete truck;
    prt.print(Printer::BottlingPlant, 'F');
}

void BottlingPlant::main() {
    truck = new Truck(prt, nameServer, *this, numVendingMachines, maxStockPerFlavour);
    while(true) {
          //or _Accept(~BottlingPlant){
              //std::cout << "before" << std::endl;
              //_Accept(getShipment) {}
              // yield(5); 
              //std::cout << "after" << std::endl;
              //delete truck;
              //prt.print(Printer::BottlingPlant, 'F');
              //break;
          //}
          yield(timeBetweenShipments);
          unsigned int producedTotal = 0;
          for (unsigned int i = 0; i < NUM_OF_FLAVOURS; ++i) {
              productionRun[i] = prng(maxShippedPerFlavour + 1);
              // std::cout << "producte flavor " << i << " " << productionRun[i] << std::endl; 
              producedTotal += productionRun[i];
          }
          prt.print(Printer::BottlingPlant, 'G', producedTotal);
          shipmentReady = true;
          // std::cout << "BottlingPlant running" << std::endl;
          _Accept(~BottlingPlant){
                break;
          }
          or _When(shipmentReady) _Accept(getShipment) { 
              prt.print(Printer::BottlingPlant, 'P');
              shipmentReady = false;
          }
    }
    // truck = NULL;
}

void BottlingPlant::getShipment( unsigned int cargo[] ) {
      if(plantClosing == true) {
          _Throw Shutdown();
      }
      for (unsigned int i = 0; i < NUM_OF_FLAVOURS; ++i) {
          cargo[i] = productionRun[i];
      }
      
}
